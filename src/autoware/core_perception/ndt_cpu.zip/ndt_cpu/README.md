# ndt_cpu

CPU version of NDT matching

## Known issues

Currently, this package contains a workaround for preventing runtime error in debug mode.  
This should be fixed in the future release.  
See [this MR](https://gitlab.com/autowarefoundation/autoware.ai/core_perception/merge_requests/57) for more details.
